package Q3;

public class Pattern02 implements Runnable
{
	Object lock;
	String art;
	int count;
	
	public Pattern02(Object lock, String art, int count)
	{
		super();
		this.lock = lock;
		this.art = art;
		this.count = count;
	}
	
	@Override
	public void run() 
	{
		// TODO Auto-generated method stub
		synchronized (lock) 
		{
			for(int i=count;i>=1;i--)
			{
				System.out.print(Thread.currentThread().getName()+" : ");
				for(int j=1;j<=i;j++)
				{
					System.out.print(" "+art+" ");
				}
				System.out.println("   ");
				try {
					Thread.sleep(1000);
					lock.notify();
					lock.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
