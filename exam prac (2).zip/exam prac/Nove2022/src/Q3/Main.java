package Q3;
import java.util.*;
public class Main
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Object lock = new Object();
		Scanner ms = new Scanner(System.in);
		
		System.out.println("Enter the pattern 01:");
		String pa1=ms.next();
		
		System.out.println("Enter the pattern 02:");
		String pa2=ms.next();
		
		System.out.println("Enter the count:");
		int co = ms.nextInt();
		
		Pattern01 p1 = new Pattern01(lock,pa1,co);
		Pattern01 p2 = new Pattern01(lock,pa2,co);
		
		Thread t1=new Thread(p1);
		Thread t2=new Thread(p2);
		
		t1.setName("Pattern01");
		t2.setName("Parretn02");
		System.out.println("======== Thread Start ========");
		t1.start();
		t2.start();
		
	}

}
