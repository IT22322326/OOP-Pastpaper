package Q3;

public class Pattern01 implements Runnable 
{
	Object lock;
	String triangle;
	int count;
	
	public Pattern01(Object lock, String triangle, int count)
	{
		super();
		this.lock = lock;
		this.triangle = triangle;
		this.count = count;
	}
	
	@Override
	public void run()
	{
		// TODO Auto-generated method stub
		synchronized (lock)
		{
			for(int i=count;i>=1;i--)
			{
				System.out.print(Thread.currentThread().getName());
				for(int j=1;j<=i;j++)
				{
					System.out.print(" " +triangle+ " ");
				}
				System.out.println("   ");
				try {
					Thread.sleep(1000);
					lock.notify();
					lock.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	

}
