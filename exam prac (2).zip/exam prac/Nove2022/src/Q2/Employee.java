package Q2;

public class Employee <T>
{
	T name;
	T empId;
	
	public Employee(T name, T empId) 
	{
		this.name = name;
		this.empId = empId;
	}

	public T getEmpId() 
	{
		return empId;
	}
	

	public T getname() 
	{
		return name;
	}
	

	
	
	
	
}
