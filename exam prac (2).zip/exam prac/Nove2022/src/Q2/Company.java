package Q2;
import java.util.*;
public class Company 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		HashMap<Integer,Employee<Object>> empList = new HashMap<>();
		
		Employee<Object> e1 = new Employee("Nishan Perera","EMP12345");
		Employee<Object> e2 = new Employee("Krishan Gamage",1234567);
		
		empList.put(e1.getEmpId().hashCode(), e1);
		empList.put(e2.getEmpId().hashCode(), e2);
		
		for(Employee E : empList.values())
		{
			System.out.println("Employee No = "+E.getEmpId()+ "   Employee name = "+ E.getname());
		}
		
		for(int id: empList.keySet())
		{
			Employee value = empList.get(id);
			System.out.println("Employee number : "+ id+ "and the Employee ID is : "+ value.getEmpId());
		}
		
		
	}

}
