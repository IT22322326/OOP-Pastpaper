package Q1;

public abstract class Customer 
{
	int id;
	String name;
	
	public Customer(int id, String name)
	{
		this.id = id;
		this.name = name;
	}
	
	public Customer()
	{
		
	}
	
	public void display()
	{
		System.out.println("id = "+ id);
		System.out.println("name = "+name);
	}
	
	public abstract void CalculateBill();
}
