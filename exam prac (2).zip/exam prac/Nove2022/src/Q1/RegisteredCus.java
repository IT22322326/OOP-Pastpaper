package Q1;
import java.util.*;
public class RegisteredCus extends Customer
{
	double rewardpoints;
	double netAmount;
	double amount;
	Scanner ms = new Scanner(System.in);
	
	public RegisteredCus(int id, String name, double rewardpoints, double netAmount)
	{
		super(id, name);
		this.rewardpoints = 0.0;
		this.netAmount = 0.0;
	}

	public RegisteredCus(int id, String name)
	{
		super(id, name);
	}
	@Override
	public void CalculateBill()
	{
		// TODO Auto-generated method stub
		System.out.println("Enter the bill amount: ");
		amount = ms.nextDouble();
		if(amount>950.00)
		{
			rewardpoints=amount*15/100.00;
			netAmount= amount-(amount*7/100.00);
		}
		else 
		{
			rewardpoints=0.0;
			netAmount= amount-(amount*7/100.00);
		}
	}
	
	@Override
	public void display()
	{
		super.display();
		System.out.println("Enter the bill amount: "+amount);
		System.out.println("Customer reward points: " + rewardpoints);
		System.out.println("Customer netamount: " + netAmount);
	}

}
