package Q1;
import java.util.*;
public class MainApp {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		ArrayList<RegisteredCus> al = new ArrayList<>();
		
		RegisteredCus r1 = new RegisteredCus(101,"Kamal");
		RegisteredCus r2 = new RegisteredCus(105,"Sunil");
		
		al.add(r1);
		al.add(r2);
		
		for(RegisteredCus R : al)
		{
			R.CalculateBill();
			R.display();
		}
		
	}

}
