package Q4;

public class FishFlavour implements IPreparedeliciously 
{

	@Override
	public void addFlavour() 
	{
		// TODO Auto-generated method stub
		System.out.println("Added fish for the flavour");
	}

	@Override
	public double getCost() 
	{
		// TODO Auto-generated method stub
		return 80.00;
	}

}
