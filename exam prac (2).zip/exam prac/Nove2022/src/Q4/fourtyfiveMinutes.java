package Q4;

public class fourtyfiveMinutes implements IPrepareQuickly {

	@Override
	public void deliveryTime() {
		// TODO Auto-generated method stub
		System.out.println("Meal is ready in 45 minutes");
	}

}
