package Q4;

public abstract class Meal 
{
	IPrepareQuickly iPrepareQuickly;
	IPreparedeliciously iPreparedeliciously;
	
	public void setDuration(IPrepareQuickly iPrepareQuickly)
	{
		this.iPrepareQuickly=iPrepareQuickly;
	}
	
	public void setFlavour(IPreparedeliciously iPreparedeliciously)
	{
		this.iPreparedeliciously=iPreparedeliciously;
	}
	
	public void mealWithFlavour()
	{
		iPreparedeliciously.addFlavour();
	}
	
	public void mealDuration()
	{
		iPrepareQuickly.deliveryTime();
	}
	
	public abstract void displayMeal();
	public abstract void displayCost();
	
}
