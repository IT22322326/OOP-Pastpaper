package Q4;

public interface IPreparedeliciously 
{
	public void addFlavour();
	public double getCost();
}
