package Q4;

public interface IPrepareQuickly 
{
	public void deliveryTime();
}
