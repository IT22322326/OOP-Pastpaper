package Q4;

public class ThirtyMinutes implements IPrepareQuickly {

	@Override
	public void deliveryTime() {
		// TODO Auto-generated method stub
		System.out.println("Meal is ready in 30 minutes");
	}

}
