package Q4;

public class Lunch extends Meal
{

	@Override
	public void displayMeal() 
	{
		// TODO Auto-generated method stub
		System.out.println("Preparing Lunch---------");
		mealWithFlavour();
		mealDuration();
		displayCost();
	}

	@Override
	public void displayCost() 
	{
		// TODO Auto-generated method stub
		System.out.println("Total amount is = "+ iPreparedeliciously.getCost());
	}

}
