package Q4;

public class OneHour implements IPrepareQuickly {

	@Override
	public void deliveryTime()
	{
		// TODO Auto-generated method stub
		System.out.println("Meal is ready in 60 minutes");

	}

}
