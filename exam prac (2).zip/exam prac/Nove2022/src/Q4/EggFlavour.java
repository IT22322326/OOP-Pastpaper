package Q4;

public class EggFlavour implements IPreparedeliciously 
{

	@Override
	public void addFlavour() 
	{
		// TODO Auto-generated method stub
		System.out.println("Added egg for the flavour");
	}

	@Override
	public double getCost() 
	{
		// TODO Auto-generated method stub
		return 60.00;
	}

}
