package Q4;

public class ChickenFlavour implements IPreparedeliciously 
{

	@Override
	public void addFlavour() 
	{
		// TODO Auto-generated method stub
		System.out.println("Added chicken for the flavour");
	}

	@Override
	public double getCost() 
	{
		// TODO Auto-generated method stub
		return 100.00;
	}

}
