package Q2;
import java.util.*;
public class Demo {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		TCalculation<Integer> t1 = new TCalculation();
		TCalculation<Double> t2 = new TCalculation();
		
		t1.append(20);
		t1.append(30);
		t1.append(40);
	
		
		t2.append(20.0);
		t2.append(30.0);
		t2.append(40.0);
		
		t1.average();
		t2.average();
	}

}
