package Q2;
import java.util.*;
public class TCalculation <T extends Number>{
	ArrayList<T> al = new ArrayList<>();

	public TCalculation(ArrayList<T> al) {
		super();
		this.al = al;
	}
	
	public TCalculation()
	{
		
	}
	
	public void append(T num)
	{
		al.add(num);
	}
	
	public double average()
	{
		double avg;
		double sum=0.0;
		for(T a:al)
		{
			sum = sum+a.doubleValue();
		}
		avg = sum/al.size();
		System.out.println("Average = "+ avg);
		return avg;
	}
	
	
	
}
