package Q4;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CarAirBag fAirbag = new Frontairbag();
		CarAirBag sAirbag = new SideAirBag();
		
		new NissanCar(fAirbag).assembleLight(); 
		new NissanCar(fAirbag).assembleMotionSensor();
		new NissanCar(sAirbag). assembleMotionSensor( ) ;
		
		new ToyatoCar(fAirbag). assembleLight( ) ;
		new ToyatoCar(fAirbag). assembleMotionSensor( ) ;
		new ToyatoCar(sAirbag). assembleLight( ) ;
		new ToyatoCar(sAirbag). assembleMotionSensor( ) ;
	}

}
