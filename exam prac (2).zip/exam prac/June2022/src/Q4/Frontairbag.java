package Q4;

public class Frontairbag implements CarAirBag {

	@Override
	public void airBagMotionDetecation() {
		// TODO Auto-generated method stub
		System.out.println("Light Indecator on for front Air Bag");
	}

	@Override
	public void airBagLightIndecator() {
		// TODO Auto-generated method stub
		System.out.println("Light Indecator on for front Air Bag");
	}

}
