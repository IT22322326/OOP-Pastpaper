package Q4;

public class SideAirBag implements CarAirBag {

	CarAirBag carAirBag;
	@Override
	public void airBagMotionDetecation() {
		// TODO Auto-generated method stub
		System.out.println("Motion dedtcation on for Side Air Bag");
	}

	@Override
	public void airBagLightIndecator() {
		// TODO Auto-generated method stub
		System.out.println("Light Indecator on for Side Air Bag");
		
	}

}
