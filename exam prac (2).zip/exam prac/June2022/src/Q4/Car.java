package Q4;

public interface Car 
{
	public void assembleLight();
	public void assembleMotionSensor();
}
