package Q4;

public class NissanCar implements Car{

	CarAirBag carAirBag;
	
	
	public NissanCar(CarAirBag carAirBag) {
		super();
		this.carAirBag = carAirBag;
	}

	@Override
	public void assembleLight() {
		// TODO Auto-generated method stub
		System.out.println("Assembling for Nissan");
		carAirBag.airBagLightIndecator();
	}

	@Override
	public void assembleMotionSensor() {
		// TODO Auto-generated method stub
		System.out.println("Assembling for Nissan");
		carAirBag.airBagMotionDetecation();
	}

}
