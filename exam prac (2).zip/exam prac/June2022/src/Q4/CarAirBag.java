package Q4;

public interface CarAirBag 
{
	public void airBagMotionDetecation();
	public void airBagLightIndecator();
	
}
