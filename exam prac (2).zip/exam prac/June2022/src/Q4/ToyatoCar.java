package Q4;

public class ToyatoCar implements Car {

	CarAirBag carAirBag;
	
	public ToyatoCar(CarAirBag carAirBag) {
		super();
		this.carAirBag = carAirBag;
	}

	@Override
	public void assembleLight() {
		// TODO Auto-generated method stub
		System.out.println("Assembling for Toyato");
		carAirBag.airBagLightIndecator();
	}

	@Override
	public void assembleMotionSensor() {
		// TODO Auto-generated method stub
		System.out.println("Assembling for Toyato");
		carAirBag.airBagMotionDetecation();
	}

}
