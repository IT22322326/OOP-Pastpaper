package Q1;

public interface PointAllocator 
{
	public void setpoint(int point);
	public int getpoint();
	
}
