
package Q1;


public class Parrot extends Pet{
	
	String command;
	
	
	public Parrot(String command) {
		super();
		this.command = command;
	}

	@Override
	public void clean() {
		// TODO Auto-generated method stub
		System.out.println("Parrot is cleaning");
		super.setpoint(getpoint()+5);
	}

	@Override
	public void feed() {
		// TODO Auto-generated method stub
		System.out.println("Parrot is feeding");
		super.setpoint(getpoint()+10);
	}

	@Override
	public void cuddle() {
		// TODO Auto-generated method stub
		System.out.println("Parrot is cuddling");
		super.setpoint(getpoint()+15);
	}

	@Override
	public double GetTotalpoints() {
		// TODO Auto-generated method stub
		return getpoint();
	}

	public void total()
	{
		System.out.println("Total is = "+ GetTotalpoints());
	}
	
	public boolean iscaught(String command)
	{
		try
		{
		if(command.equalsIgnoreCase("Walk"))
		{
			throw new CaughtException("Parrot is caught");
		}
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
			return true;
		}
		System.out.println("Parrot is safe");
		return false;
	}
}
