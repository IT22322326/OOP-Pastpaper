package Q1;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Squirrel s1 = new Squirrel("Runfor5times");
		s1.isCaught("Runfor5times");
		Pet squirrell =new Squirrel("Run3");
		squirrell.cuddle();
		squirrell.feed();
		s1.isCaught("RUn3");
		squirrell.GetTotalpoints();
		squirrell . total ( );
		Pet squirrel2 =new Squirrel("Runfor5times");
		squirrel2 . cuddle( ) ;
		squirrel2 . feed( ) ;
		s1.isCaught("Runfor5times");
		squirrel2.GetTotalpoints();
		squirrel2 . total ( ) ;
		Pet garfield =new Cat();
		garfield.clean();
		garfield.cuddle();
		garfield . feed ( ) ;
		garfield.GetTotalpoints();
		garfield . GetTotalpoints ( ) ;
		Pet parrotl =new Parrot("walk");
		parrotl . feed( ) ;
		parrotl.GetTotalpoints();
		parrotl . total() ;
	}

}
