package Q1;

public class CaughtException extends Exception
{

	public CaughtException(String message) 
	{
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
