package Q1;

public abstract class Pet implements PointAllocator 
{

	private int point;
	
	@Override
	public void setpoint(int point) {
		// TODO Auto-generated method stub
		this.point=point;
	}

	@Override
	public int getpoint() {
		// TODO Auto-generated method stub
		return 0;
	}

	public abstract void clean();
	public abstract void feed();
	public abstract void cuddle();
	public abstract double GetTotalpoints();

	public abstract void total();

}
