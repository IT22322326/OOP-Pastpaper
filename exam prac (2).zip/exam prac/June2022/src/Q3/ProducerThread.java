package Q3;
import java.util.*;;
public class ProducerThread implements Runnable
{
	ArrayList<Integer> q1 ;
	int elements = 10;
	
	
	public ProducerThread(ArrayList<Integer> q1) {
		super();
		this.q1 = q1;
	}


	@Override
	public void run() {
		synchronized (q1)
		{
			while(true)
			{
				System.out.println("Producer started");
				System.out.println("Starting");
				q1.add(elements);
				System.out.println(Thread.currentThread().getName()+"produces"+elements);
				elements = elements+10;
				
				try {
					Thread.sleep(1000);
					q1.notify();
					q1.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		// TODO Auto-generated method stub
		
	}

}
