package Q3;
import java.util.*;
public class Threadtest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> q = new ArrayList<Integer>();
		
		ProducerThread p1 = new ProducerThread(q);
		ConsumerThread c1 = new ConsumerThread(q);
		
		Thread t1 = new Thread(p1);
		Thread t2 = new Thread(c1);
		
		t1.setName("ProducerThread");
		t2.setName("ConsumerThread");
		
		System.out.println(" ");
		
		t1.start();
		t2.start();
	}

}