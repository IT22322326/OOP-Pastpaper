package Q3;
import java.util.*;
public class ConsumerThread implements Runnable
{
	ArrayList <Integer> q1 ;
	
	public ConsumerThread(ArrayList<Integer> q1) {
		super();
		this.q1 = q1;
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized (q1) 
		{
			while(true)
			{
			System.out.println("Consumer started");
			q1.remove(0);
			System.out.println(Thread.currentThread().getName()+"consumes"+q1);
			try {
				Thread.sleep(1000);
				q1.notify();
				q1.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			
		}
	}

}
