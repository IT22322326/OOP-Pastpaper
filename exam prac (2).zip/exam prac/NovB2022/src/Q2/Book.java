package Q2;

public class Book <T>{
	
	T bookTitle;
	T BookISBN;
	
	public Book(T bookTitle, T bookISBN) {
		super();
		this.bookTitle = bookTitle;
		BookISBN = bookISBN;
	}

	public T getBookISBN() {
		return BookISBN;
	}

	public T getBookTitle() {
		return bookTitle;
	}
	
	
	
}
