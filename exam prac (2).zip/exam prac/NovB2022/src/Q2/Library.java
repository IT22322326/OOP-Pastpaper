package Q2;
import java.util.*;
public class Library {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,Book<Object>> bookList = new HashMap<>();
		
		Book<Object> b1 = new Book("Harry Potter","ISBN12345");
		Book<Object> b2 = new Book("Rings of Power",123456);
		
		bookList.put(b1.getBookISBN().hashCode(), b1);
		bookList.put(b2.getBookISBN().hashCode(), b2);
		
		for(int id: bookList.keySet())
		{
			Book value = bookList.get(id);
			System.out.println("Book ID is: "+ id + "and the ISBN is: " + value.getBookISBN());
		}
	}

}
