package Q3;

public class Pattern01 implements Runnable{

	Object lock;
	String pattern;
	int count;
	
	public Pattern01(Object lock, String pattern, int count) {
		super();
		this.lock = lock;
		this.pattern = pattern;
		this.count = count;
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized (lock) 
		{
			for(int i=1;i<count;i++)
			{
				System.out.print(Thread.currentThread().getName()+"=");
				for(int j=1;j<=i;j++)
				{
					System.out.print(" "+pattern+" ");
				}
				System.out.println("");
				try {
					Thread.sleep(1000);
					lock.notify();
					lock.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
