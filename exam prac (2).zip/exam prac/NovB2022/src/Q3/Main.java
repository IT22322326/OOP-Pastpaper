package Q3;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ms = new Scanner(System.in);
		
		Object lock = new Object();
		
		System.out.println("Enter the pattern1:");
		String Pattern1 = ms.next();
		
		System.out.println("Enter the pattern2:");
		String Pattern2 = ms.next();
		
		System.out.println("Enter the count:");
		int count = ms.nextInt();
		
		//Pattern01 p1 = new Pattern01(lock,Pattern1,count);
		//Pattern02 p2 = new Pattern02(lock,Pattern2,count);
		
		Thread t1 = new Thread(new Pattern01(lock,Pattern1,count));
		Thread t2 = new Thread( new Pattern02(lock,Pattern2,count));
		
		t1.setName("Thread01");
		t2.setName("Thread02");
		
		System.out.println("========ThreadStart========");
		
		t1.start();
		t2.start();
	}

}
