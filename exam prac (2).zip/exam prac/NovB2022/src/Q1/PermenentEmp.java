package Q1;

public class PermenentEmp extends Employee{
	
	double basicSal;
	double commission;
	double NetSalary;
	
	
	public PermenentEmp(int id, String name, double basicSal, double commission) {
		super(id, name);
		this.basicSal = basicSal;
		this.commission = commission;
	}

	@Override
	public double calculateNetSalary() {
		// TODO Auto-generated method stub
		NetSalary=basicSal+commission;
		return NetSalary;
	}
	
	public void display()
	{
		super.display();
		System.out.println("basicSal = " + basicSal);
		System.out.println("commission = " + commission);
		System.out.println("NetSalary = " + NetSalary);
		
	}
	
	
	
	
}
