package Q1;

public class TemporaryEmp extends Employee
{
	int Othrs;
	double OtRate;
	double minWage;
	double NetSalary;
	
	public TemporaryEmp(int id, String name, int othrs, double otRate) {
		super(id, name);
		Othrs = othrs;
		OtRate = otRate;
		this.minWage = 15000.00;
	}
	
	public double getMinWage() {
		return minWage;
	}

	public void setMinWage(double minWage) {
		this.minWage = 15000.00;
	}

	@Override
	public double calculateNetSalary() {
		// TODO Auto-generated method stub
		NetSalary=minWage+(Othrs*OtRate);
		return NetSalary;
	}
	
	public void display()
	{
		super.display();
		System.out.println("minWage = " +minWage);
		System.out.println("NetSalary = " +NetSalary);
	}
	
}
