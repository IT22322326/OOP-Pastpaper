package Q1;
import java.util.*;
public class DemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<PermenentEmp> p = new ArrayList();
		PermenentEmp p1 = new PermenentEmp(101,"Nimali",56000.00,8400.00);
		PermenentEmp p2 = new PermenentEmp(102,"Amal",74000.00,11100.00);
		
		p.add(p1);
		p.add(p2);
		
		for(PermenentEmp a: p)
		{
			a.calculateNetSalary();
			a.display();
		}
		
		ArrayList<TemporaryEmp> t = new ArrayList();
		TemporaryEmp t1 = new TemporaryEmp(201,"Sunil",5,1000.00);
		TemporaryEmp t2 = new TemporaryEmp(202,"Piyal",15,1000.00);
		
		t.add(t1);
		t.add(t2);
		
		for(TemporaryEmp a1: t)
		{
			a1.calculateNetSalary();
			a1.display();
		}
	}

}
