package Q1;

public abstract class Employee {
	int id;
	String name;
	
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public void display()
	{
		System.out.println("id = "+id);
		System.out.println("name = "+ name);
	}
	
	public abstract double calculateNetSalary();
	
	
}
