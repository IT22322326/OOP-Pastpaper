package Q4;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MobileUI mobileUI = new MobileUI();
		Oven mainoven = new Oven("Main");
		GarageGate garagaGate = new GarageGate("GMain");
		
		Command c1 = new Ovenon(mainoven);
		Command c2 = new ovenOff(mainoven);
		
		Command c3 = new GarageGateOpen(garagaGate);
		Command c4 = new GarageGateClose(garagaGate);
		
		c1.execute();
		c2.execute();
		c3.execute();
		c4.execute();
		
		mobileUI.setcommand(0, c1);
		mobileUI.setcommand(1, c2);
		mobileUI.setcommand(2, c3);
		mobileUI.setcommand(3, c4);
		
		mobileUI.commandPressed(0);
		mobileUI.commandPressed(1);
		mobileUI.commandPressed(2);
		mobileUI.commandPressed(4);
	}

}
