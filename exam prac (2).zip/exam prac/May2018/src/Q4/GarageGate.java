package Q4;

public class GarageGate {
	String description;

	public GarageGate(String description) {
		super();
		this.description = description;
	}
	
	public void open()
	{
		System.out.println("GarageGate is open");
	}
	
	public void close()
	{
		System.out.println("GarageGate is close");
	}
}
