package Q4;

public class GarageGateOpen implements Command {

	GarageGate garageGat;

	public GarageGateOpen(GarageGate garageGat) {
		super();
		this.garageGat = garageGat;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		garageGat.open();
	}

}
