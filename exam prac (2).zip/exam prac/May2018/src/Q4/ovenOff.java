package Q4;

public class ovenOff implements Command {

	Oven oven;
	
	
	public ovenOff(Oven oven) {
		super();
		this.oven = oven;
	}


	@Override
	public void execute() {
		// TODO Auto-generated method stub
		oven.off();
	}

}
