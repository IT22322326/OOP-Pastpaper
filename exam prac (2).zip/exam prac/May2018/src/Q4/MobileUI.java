package Q4;

public class MobileUI {
	Command[] Command;

	public MobileUI(Q4.Command[] command) {
		super();
		Command = new Command[6];
	}
	
	public MobileUI()
	{
		
	}
	
	public void setcommand(int index,Command cmdObj)
	{
		Command[index]=cmdObj;
	}
	
	public void commandPressed(int index)
	{
		Command[index].execute();
	}
	
	
}
