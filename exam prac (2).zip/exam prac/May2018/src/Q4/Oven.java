package Q4;

public class Oven {
	String name;

	public Oven(String name) {
		super();
		this.name = name;
	}
	
	public void on()
	{
		System.out.println("Oven is on");
	}
	
	public void off()
	{
		System.out.println("Oven is off");
	}
}
