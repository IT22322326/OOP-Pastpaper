package Q4;
import java.util.*;
public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CreditCard c1 = CreditCard.getInstance();
		CreditCard c2 = CreditCard.getInstance();
		
		c1.validate("Aba1234567890123", 9);
		c1.validate("1234567889", 27);
	}

}
