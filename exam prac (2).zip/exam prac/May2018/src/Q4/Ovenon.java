package Q4;

public class Ovenon implements Command{

Oven oven;
	
	public Ovenon(Oven oven) {
		super();
		this.oven = oven;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		oven.on();
	}

}
