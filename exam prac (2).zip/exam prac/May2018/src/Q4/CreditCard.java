package Q4;

public class CreditCard {
	private static CreditCard instance;
	
	private CreditCard()
	{
		
	}
	
	public static CreditCard getInstance()
	{
		if(instance==null)
		{
			instance=new CreditCard();
		}
		return instance;
	}
	
	public boolean validate(String cardno,int code)
	{
		if(cardno.length()==16 && code%3==0)
		{
			System.out.println("Validate");
			return true;
		}
	
		System.out.println("Invalid");
		return false;
	}
}
