package Q4;

public class GarageGateClose implements Command {

	GarageGate garageGat;

	public GarageGateClose(GarageGate garageGat) {
		super();
		this.garageGat = garageGat;
	}


	@Override
	public void execute() {
		// TODO Auto-generated method stub
		garageGat.close();
	}

}
