package Q1;
import java.util.*;
public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Item> al = new ArrayList<>();
		
		Book b1 = new Book("B1","Love",250.00,"Love","Ragul",20);
		Book b2 = new Book("B1","Love",250.00,"Love","Ragul",20);
		
		al.add(b1);
		al.add(b2);
		
		Car c1 = new Car("C1","Toyato",450000.00,"Toyato","New");
		Car c2 = new Car("C1","Toyato",450000.00,"Toyato","New");
		
		al.add(c1);
		al.add(c2);
		
		for(Item i : al)
		{
			i.display();
		}
				

	}

}
