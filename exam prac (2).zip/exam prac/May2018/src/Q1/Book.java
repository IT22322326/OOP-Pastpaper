package Q1;

public class Book extends Item{

	String categeory;
	String publisher;
	int pages;
	
	public Book(String itemNo, String description, double unitPrice, String categeory, String publisher, int pages) {
		super(itemNo, description, unitPrice);
		this.categeory = categeory;
		this.publisher = publisher;
		this.pages = pages;
	}
	
	public void display()
	{
		super.display();
		System.out.println("categeory = "+ categeory);
		System.out.println("publisher = "+ publisher);
		System.out.println("pages = "+ pages);
	}
	
}
