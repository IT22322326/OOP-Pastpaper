package Q1;

public abstract class Item {
	String itemNo;
	String description;
	double unitPrice;
	
	public Item(String itemNo, String description, double unitPrice) {
		super();
		this.itemNo = itemNo;
		this.description = description;
		this.unitPrice = unitPrice;
	}
	
	public Item()
	{
		
	}
	
	public void display()
	{
		System.out.println("itemNo = "+ itemNo);
		System.out.println("description = "+ description);
		System.out.println("unitPrice = "+ unitPrice);
	}
}
