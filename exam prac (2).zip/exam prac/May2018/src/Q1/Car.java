package Q1;

public class Car extends Item
{
	String model;
	String type;
	
	public Car(String itemNo, String description, double unitPrice, String model, String type) {
		super(itemNo, description, unitPrice);
		this.model = model;
		this.type = type;
	}
	
	public void display()
	{
		super.display();
		System.out.println("model = "+ model);
		System.out.println("type = "+ type);
	}
}
