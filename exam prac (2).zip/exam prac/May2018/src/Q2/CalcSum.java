package Q2;

public class CalcSum implements Runnable{
	
	Object lock;
	int sum = 0;
	public CalcSum( Object lock) {
		super();
	this.lock = lock;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized (lock) 
		{
			for(int i=1;i<=100000;i++)
			{
				
				sum=sum+i;
				System.out.println(Thread.currentThread().getName()+i);
			/*	try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
			}
			System.out.println("sum = "+sum);
		}
	}
	
	
}
