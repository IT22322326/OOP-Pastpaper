package Q2;
import java.util.*;
public class MainThreadApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object lock = new Object();
		CountDown c1 = new CountDown(lock);
		CalcSum c2 = new CalcSum(lock);
		CalcSum c3 = new CalcSum(lock);
				
		//Thread t1 = new Thread(c1);
		Thread t2 = new Thread(c2);
		Thread t3 = new Thread(c3);
		
		c1.setName("Countdown");
		t2.setName("Black");
		t3.setName("White");
		
		c1.start();
		try {
			c1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t2.start();
		t3.start();
		
	}

}
