package Q2;

public class CountDown extends Thread{
	
	Object lock;
	
	public CountDown( Object lock) {
		super();
		this.lock = lock;
	}
	
	public void run(){
		synchronized (lock) 
		{
			for(int i=1;i<=10;i++)
			{
				System.out.println(Thread.currentThread().getName()+" "+i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	
}
