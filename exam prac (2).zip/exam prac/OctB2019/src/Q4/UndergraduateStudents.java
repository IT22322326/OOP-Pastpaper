package Q4;

public class UndergraduateStudents extends Student{

	@Override
	public void displayStudents() {
		// TODO Auto-generated method stub
		offerProgramms ();
		conductEvent();
		displayCost();
	}

	@Override
	public void displayCost() {
		// TODO Auto-generated method stub
		System.out.println("Cost = "+Iprograms.getcost());
	}

}
