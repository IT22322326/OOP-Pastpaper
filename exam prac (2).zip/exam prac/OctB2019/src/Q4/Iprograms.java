package Q4;

public interface Iprograms {
	public void offerprogramms();
	public double getcost();
	
}
