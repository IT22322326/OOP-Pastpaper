package Q4;

public abstract class Student {
	Iprograms Iprograms;
	Ifestival Ifestival;
	
	public void setIprograms(Iprograms iprograms) {
		Iprograms = iprograms;
	}
	public void setfestival(Ifestival ifestival) {
		Ifestival = ifestival;
	}
	
	public void offerProgramms()
	{
		Iprograms.offerprogramms();
	}
	
	public void conductEvent()
	{
		Ifestival.performEvent();
	}
	
	public abstract void displayStudents();
	public abstract void displayCost();
	
}
