package Q4;

public class PostgraduateStudents extends Student {

	public void displayStudents() {
		// TODO Auto-generated method stub
		offerProgramms ();
		conductEvent();
		displayCost();
	}
	
	public void displayCost() {
		// TODO Auto-generated method stub
		System.out.println("Cost = "+Iprograms.getcost());
	}

}
