package Q4;

public class MScPrograms implements Iprograms {

	@Override
	public void offerprogramms() {
		// TODO Auto-generated method stub
		System.out.println("Offer MSc Programms");
	}

	@Override
	public double getcost() {
		// TODO Auto-generated method stub
		return 500000.00;
	}

}
