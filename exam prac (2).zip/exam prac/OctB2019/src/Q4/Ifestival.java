package Q4;

public interface Ifestival {
	public void performEvent();
	public double getbudget();
}
