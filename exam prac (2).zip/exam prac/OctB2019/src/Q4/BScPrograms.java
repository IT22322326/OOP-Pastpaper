package Q4;

public class BScPrograms implements Iprograms {

	@Override
	public void offerprogramms() {
		// TODO Auto-generated method stub
		System.out.println("Offer BSc Programms");
	}

	@Override
	public double getcost() {
		// TODO Auto-generated method stub
		return 120000.00;
	}

}
