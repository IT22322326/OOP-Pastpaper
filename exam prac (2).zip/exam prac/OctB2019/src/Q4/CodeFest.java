package Q4;

public class CodeFest implements Ifestival {

	@Override
	public void performEvent() {
		// TODO Auto-generated method stub
		System.out.println("Perform CodeFest event for "+getbudget());
	}

	@Override
	public double getbudget() {
		// TODO Auto-generated method stub
		return 300000.00;
	}

}
