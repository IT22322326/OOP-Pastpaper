package Q4;

public class PhDPrograms implements Iprograms {

	@Override
	public void offerprogramms() {
		// TODO Auto-generated method stub
		System.out.println("Offer PhD Programms");
	}

	@Override
	public double getcost() {
		// TODO Auto-generated method stub
		return 1200000.00;
	}

}
