package Q4;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student p= new PostgraduateStudents (); 
		p.setfestival(new CodeFest()); 
		p.setIprograms(new MScPrograms ()); 
		p.displayStudents(); 
		
		System.out.println(); 
		
		Student u = new UndergraduateStudents (); 
		u.setfestival(new RoboFest()); 
		u.setIprograms(new BScPrograms()); 
		u.displayStudents();
		
		
	}

}
