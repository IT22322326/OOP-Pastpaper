package Q4;

public class GameFest implements Ifestival {

	@Override
	public void performEvent() {
		// TODO Auto-generated method stub
		System.out.println("Perform GameFest event for "+getbudget());
	}

	@Override
	public double getbudget() {
		// TODO Auto-generated method stub
		return 400000.00;
	}

}
