package Q3;

public interface IEmployee {
	public String showEmployeeDetails();
}
