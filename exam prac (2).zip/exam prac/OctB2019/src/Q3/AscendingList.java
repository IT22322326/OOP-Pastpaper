package Q3;
import java.util.*;
public class AscendingList<K,V> {
	TreeMap<K,V> t = new TreeMap<>();

	public AscendingList(TreeMap<K, V> t) {
		super();
		this.t = t;
	}
	public AscendingList()
	{
		
	}
	public void append(K a,V b)
	{
		t.put(a, b);
	}
	
	public void displayMyList()
	{
		for(Map.Entry<K, V> map : t.entrySet())
		{
			System.out.println(map.getValue());
		}
	}
	
}
