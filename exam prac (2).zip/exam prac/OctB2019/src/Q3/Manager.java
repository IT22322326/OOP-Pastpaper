package Q3;

public class Manager implements IEmployee {
	
	String ManagerId;
	double salary;
	
	
	public Manager(String managerId, double salary) {
		super();
		ManagerId = managerId;
		this.salary = salary;
	}


	@Override
	public String showEmployeeDetails() {
		// TODO Auto-generated method stub
		return "ManagerId = " + ManagerId + "     salary = "+ salary;
	}

}
