package Q3;

import java.util.ArrayList;

public class GenericDemo {
	
	public <T extends IEmployee> void showElements(ArrayList<T> al)
	{
		for(T a : al)
		{
			System.out.println(a.showEmployeeDetails());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Engineer> e1 = new ArrayList<>();
		ArrayList<Manager> m1 = new ArrayList<>();
		
		Engineer a0= new Engineer("E1","IFS");
		Engineer a1= new Engineer("E1","IFS");
		Engineer a2= new Engineer("E1","IFS");
		Engineer a3= new Engineer("E1","IFS");
		Engineer a4= new Engineer("E1","IFS");
		
		Manager b0 = new Manager("M1",25000.00);
		Manager b1 = new Manager("M1",25000.00);
		Manager b2 = new Manager("M1",25000.00);
		Manager b3 = new Manager("M1",25000.00);
		Manager b4 = new Manager("M1",25000.00);
		
		e1.add(a0);
		e1.add(a1);
		e1.add(a2);
		e1.add(a3);
		e1.add(a4);
		
		m1.add(b0);
		m1.add(b1);
		m1.add(b2);
		m1.add(b3);
		m1.add(b4);
		
		
		GenericDemo g = new GenericDemo();
		g.showElements(e1);
		System.out.println("");
		g.showElements(m1);
		
	}

}
