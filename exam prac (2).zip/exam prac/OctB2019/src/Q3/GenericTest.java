package Q3;
import java.util.*;
public class GenericTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AscendingList<Integer,String> q = new AscendingList<>();
		q.append(10, "mala");
		q.append(20, "qqqq");
		q.append(40, "null");
		q.append(40, "kala");
		
		AscendingList<Integer,Integer> q1 = new AscendingList<>();
		q1.append(10, 10);
		q1.append(10, 20);
		q1.append(30, 10);
		
		q.displayMyList();
		q1.displayMyList();
		
	}

}
