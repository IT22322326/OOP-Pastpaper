package Q3;

public class Engineer implements IEmployee {
	
	String employeeId;
	String company;
	
	
	public Engineer(String employeeId, String company) {
		super();
		this.employeeId = employeeId;
		this.company = company;
	}


	@Override
	public String showEmployeeDetails() {
		// TODO Auto-generated method stub
		return "employeeId = " + employeeId + "   company = " + company;
	}

}
