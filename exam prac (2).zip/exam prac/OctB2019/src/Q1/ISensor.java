package Q1;

public interface ISensor 
{
	public void on();
	public void off();
	
}
