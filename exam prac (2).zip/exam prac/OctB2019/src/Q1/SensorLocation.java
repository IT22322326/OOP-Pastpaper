package Q1;

public class SensorLocation implements IMotionTracker {
	
	String loation;
	
	public SensorLocation(String loation) {
		super();
		this.loation = loation;
	}


	@Override
	public void displayLocation() {
		// TODO Auto-generated method stub
		System.out.println("Sensor location is = " +loation);
	}

}
