package Q1;

public class SensorDEmo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ISensor h =new HumaditySensor("Robo");
		ISensor r = new RainFallSensor("Weera");
		IMotionTracker lh = new SensorLocation("Colombo");
		IMotionTracker lr = new SensorLocation("Kandy");
		
		ISensor[] is = new ISensor[] {h,r};
		IMotionTracker[] im = new IMotionTracker[] {lh,lr};
		
		Remotecontroller r1 = new Remotecontroller(0,im,is);
		Remotecontroller r2 = new Remotecontroller(1,im,is);
		
		r1.startservice();
		r1.stopservice();
		r1.displayLocation();
		
		r2.startservice();
		r2.stopservice();
		r2.displayLocation();
		
	}

}
