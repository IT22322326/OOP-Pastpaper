package Q1;

public class HumaditySensor implements ISensor {
	
	String name;
	
	
	public HumaditySensor(String name) {
		super();
		this.name = name;
	}

	@Override
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("HumaditySensor switch on");
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("HumaditySensor switch on");
	}

}
