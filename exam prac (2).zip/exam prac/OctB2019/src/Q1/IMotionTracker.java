package Q1;

public interface IMotionTracker {
	public void displayLocation();
}
