package Q1;

public class Remotecontroller {
	int switchs;
	IMotionTracker IMotionTracker[];
	ISensor ISensor[];
	
	public Remotecontroller(int switchs, Q1.IMotionTracker[] iMotionTracker, Q1.ISensor[] iSensor) {
		super();
		this.switchs = switchs;
		IMotionTracker = iMotionTracker;
		ISensor = iSensor;
	}
	
	public Remotecontroller()
	{
		
	}

	public int getSwitchs() {
		return switchs;
	}

	public void setSwitchs(int switchs) {
		this.switchs = switchs;
	}

	public IMotionTracker[] getIMotionTracker() {
		return IMotionTracker;
	}

	public void setIMotionTracker(IMotionTracker[] iMotionTracker) {
		IMotionTracker = iMotionTracker;
	}

	public ISensor[] getISensor() {
		return ISensor;
	}

	public void setISensor(ISensor[] iSensor) {
		ISensor = iSensor;
	}
	
	public void startservice()
	{
		if(switchs==0)
		{
			ISensor[0].on();
		}
		else
		{
			ISensor[1].on();
		}
	}
	
	public void stopservice()
	{
		if(switchs==0)
		{
			ISensor[0].off();
		}
		else
		{
			ISensor[1].off();
		}
	}
	
	public void displayLocation()
	{
		if(switchs==0)
		{
			IMotionTracker[0].displayLocation();
		}
		else
		{
			IMotionTracker[1].displayLocation();
		}
	}
	
	
}
