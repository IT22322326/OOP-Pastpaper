package Q2;

public interface IPerson {
	public String displayDetails();
}
