package Q2;
import java.util.*;
public class GenerivcDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	AssendingTable<Integer, String> my = new AssendingTable<>();
	my.AddElements(40, "aaa");
	my.AddElements(10, "bbb");
	my.AddElements(40, "bbb");
	
	AssendingTable<Integer, Double> my1 = new AssendingTable<>(); 
	my1.AddElements(40, 10.123); 
	my1.AddElements(30, 23.456); 
	my1.AddElements(20, 34.567); 
	 
	my.display();
	my1.display();
	
	}

}
