package Q2;
import java.util.*;
public class AssendingTable<K, V> {

	TreeMap<K,V> table = new TreeMap<>();
	
	public AssendingTable(TreeMap<K, V> table) {
		super();
		this.table = table;
	}

	public AssendingTable()
	{
		
	}
	
	public void AddElements(K a1,V b1)
	{
		table.put(a1, b1);
	}
	
	public TreeMap<K, V> getTable() {
		return table;
	}

	public void setTable(TreeMap<K, V> table) {
		this.table = table;
	}

	public void display()
	{
		for(Map.Entry<K, V> a : table.entrySet())
		{
			System.out.println(a.getKey()+" "+ a.getValue());
		}
	}

}
