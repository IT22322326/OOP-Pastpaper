package Q2;

public class Lecturer implements IPerson {

	String empId;
	String Department;
	
	
	public Lecturer(String empId, String department) {
		super();
		this.empId = empId;
		Department = department;
	}

	@Override
	public String displayDetails() {
		// TODO Auto-generated method stub
		return "EmpID = " + empId+"     Department = "+ Department;
	}

}
