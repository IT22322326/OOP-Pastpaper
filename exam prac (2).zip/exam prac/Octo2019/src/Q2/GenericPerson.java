package Q2;
import java.util.*;
public class GenericPerson {

	public <T extends IPerson> void displayElements(ArrayList<T> al) 
	{
		for(T a: al)
		{
			System.out.println(a.displayDetails());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Student> al1 = new ArrayList<>();
		ArrayList<Lecturer> al2 = new ArrayList<>();
		
		Student s1 = new Student("IT1",6);
		Student s2 = new Student("IT2",7);
		Student s3 = new Student("IT3",8);
		Student s4 = new Student("IT4",9);
		Student s5 = new Student("IT4",10);
		
		al1.add(s1);
		al1.add(s2);
		al1.add(s3);
		al1.add(s4);
		al1.add(s5);
		
		Lecturer l1 = new Lecturer("E1","IT");
		Lecturer l2 = new Lecturer("E2","SE");
		Lecturer l3 = new Lecturer("E3","CSN");
		Lecturer l4 = new Lecturer("E4","EE");
		Lecturer l5 = new Lecturer("E5","IS");
		
		al2.add(l1);
		al2.add(l2);
		al2.add(l3);
		al2.add(l4);
		al2.add(l5);
		
		GenericPerson g = new GenericPerson();
		g.displayElements(al1);
		g.displayElements(al2);
				
		
	}

}
