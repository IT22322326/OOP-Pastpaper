package Q2;

public class Student implements IPerson {

	String Sid;
	int grade;
	
	
	public Student(String sid, int grade) {
		super();
		Sid = sid;
		this.grade = grade;
	}


	@Override
	public String displayDetails() {
		// TODO Auto-generated method stub
		return "SID = "+ Sid+"     Grade = "+ grade;
	}

}
