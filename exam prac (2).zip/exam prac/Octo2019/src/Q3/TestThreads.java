package Q3;

public class TestThreads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object o1 = new Object();
		
		PlusThread p1 = new PlusThread(o1,2,10);
		Multiplythread m1 = new Multiplythread(o1,2,10);
		
		Thread t1 = new Thread(p1);
		Thread t2 = new Thread(m1);
		
		t1.setName("Thread-0");
		t2.setName("Thread-1");
		
		t2.start();
		t1.start();
		
	}

}
