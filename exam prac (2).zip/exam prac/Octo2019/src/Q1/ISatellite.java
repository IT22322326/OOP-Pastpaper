package Q1;

public interface ISatellite 
{
	public void activate();
	public void deactivate();
}
