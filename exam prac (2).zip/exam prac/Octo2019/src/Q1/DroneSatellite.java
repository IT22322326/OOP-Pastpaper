package Q1;

public class DroneSatellite implements ISatellite {

	String name;
	
	public DroneSatellite(String name) {
		super();
		this.name = name;
	}
	@Override
	public void activate() {
		// TODO Auto-generated method stub
		System.out.println(name + " DroneSatellite activate");
	}

	@Override
	public void deactivate() {
		// TODO Auto-generated method stub
		System.out.println(name+" DroneSatellite deactivate");
	}

}
