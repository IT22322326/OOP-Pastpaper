package Q1;
import java.util.*;


public class SatelliteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ISatellite navigationsaterliite = new NavigationSatellite("Ravana01");
		IGeoLocation locationsever = new SatelliteLocation("Srilanka");
		ISatellite droneSatellite = new DroneSatellite("Ravana02");
		IGeoLocation locationsever1 = new SatelliteLocation("Russia");
		
		ISatellite [] sateliteArray = new ISatellite[] {navigationsaterliite,droneSatellite};
		IGeoLocation [] locationArray = new IGeoLocation[] {locationsever,locationsever1};
		
		SatelliteCenter satelliteCenter = new SatelliteCenter(0,sateliteArray,locationArray);
		satelliteCenter.startService();
		satelliteCenter.stopService();
		satelliteCenter.locationservice();
		
		System.out.println("");
		
		SatelliteCenter satelliteCenter1 = new SatelliteCenter(1,sateliteArray,locationArray);
		satelliteCenter1.startService();
		satelliteCenter1.stopService();
		satelliteCenter1.locationservice();
	}

}
