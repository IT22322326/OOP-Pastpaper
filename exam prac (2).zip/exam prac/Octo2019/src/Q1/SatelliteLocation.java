package Q1;

public class SatelliteLocation implements IGeoLocation {

	String location;
	
	public SatelliteLocation(String location) {
		super();
		this.location = location;
	}


	@Override
	public void displayLocation() {
		// TODO Auto-generated method stub
		System.out.println("SatelliteLocation is ="+location);
	}

}
