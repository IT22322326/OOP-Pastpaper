package Q1;

public interface IGeoLocation 
{
	public void displayLocation();
}
