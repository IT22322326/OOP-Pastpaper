package Q1;

public class SatelliteCenter {
	
	int options;
	ISatellite ISatellite[];
	IGeoLocation IGeoLocation[];
	
	public SatelliteCenter(int options, Q1.ISatellite[] iSatellite, Q1.IGeoLocation[] iGeoLocation) 
	{
		super();
		this.options = options;
		ISatellite = iSatellite;
		IGeoLocation = iGeoLocation;
	}
	
	
	public int getOptions() {
		return options;
	}


	public void setOptions(int options) {
		this.options = options;
	}


	public ISatellite[] getISatellite() {
		return ISatellite;
	}


	public void setISatellite(ISatellite[] iSatellite) {
		ISatellite = iSatellite;
	}


	public IGeoLocation[] getIGeoLocation() {
		return IGeoLocation;
	}


	public void setIGeoLocation(IGeoLocation[] iGeoLocation) {
		IGeoLocation = iGeoLocation;
	}


	public void startService()
	{
		if(options==0)
		{
			ISatellite[0].activate();
		}
		else
		{
			ISatellite[1].activate();
		}
	}
	
	public void stopService()
	{
		if(options==0)
		{
			ISatellite[0].deactivate();
		}
		else
		{
			ISatellite[1].deactivate();
		}
	}
	
	public void locationservice()
	{
		if(options==0)
		{
			IGeoLocation[0].displayLocation();
		}
		else
		{
			IGeoLocation[1].displayLocation();
		}
	}
	
	
}
