package Q1;
import java.util.*;

public class StudentApp 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		ArrayList<Student> al = new ArrayList<>();
		ArrayList<Course> al1 = new ArrayList<>();
		Student s1 = new Student();
		Student s2 = new Student();
		
		Course c1 = new Course();
		Course c2 = new Course();
		
		s1.Read();
		s2.Read();
		c1.Read();
		c2.Read();
		
		c1.AddStudent(s1);
		c1.AddStudent(s2);
		c2.AddStudent(s1);
		
		al.add(s1);
		al.add(s2);
		
		al1.add(c1);
		al1.add(c2);
		
		System.out.println("StudentInformation: ");
		for(Student sts : al)
		{
			sts.print();
		}

		System.out.println("CourseInformation: ");
		for(Course cs : al1)
		{
			cs.display();
		}
		
		/*s1.print();
		s2.print();
		c1.display();
		c2.display();*/
		
	}

}
