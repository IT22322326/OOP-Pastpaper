package Q1;
import java.util.*;
public class Student 
{
	Scanner ms = new Scanner(System.in);
	String StudentId;
	String name;
	String address;
	String contact_number;
	
	public Student(String studentId, String name, String address, String contact_number) 
	{
		StudentId = studentId;
		this.name = name;
		this.address = address;
		this.contact_number = contact_number;
	}
	
	
	public String getStudentId() {
		return StudentId;
	}


	public String getName() {
		return name;
	}


	public String getAddress() {
		return address;
	}


	public String getContact_number() {
		return contact_number;
	}


	public Student()
	{
		
	}
	
	public void Read()
	{
		System.out.println("Enter the StudentId: ");
		StudentId= ms.next();
		System.out.println("Enter the name: ");
		name= ms.next();
		System.out.println("Enter the address: ");
		address= ms.next();
		System.out.println("Enter the contact_number: ");
		contact_number= ms.next();
	}
	
	public void print()
	{
		System.out.println("StudentId: "+StudentId);
		System.out.println("name: "+name);
		System.out.println("address: "+address);
		System.out.println("contact_number: "+contact_number);
	}
}
