package Q1;
import java.util.*;
public class Course
{
	Scanner ms = new Scanner(System.in);
	String CourseID;
	String name;
	String instructor;
	ArrayList<Student> al = new ArrayList<>();
	
	public Course(String courseID, String name, String instructor)
	{
		CourseID = courseID;
		this.name = name;
		this.instructor = instructor;
	}
	
	public Course()
	{
		
	}
	public void Read()
	{
		System.out.println("Enter the courseID: ");
		CourseID = ms.next();
		System.out.println("Enter the name: ");
		name = ms.next();
		System.out.println("Enter the address: ");
		instructor = ms.next();
	}
	
	public void AddStudent(Student st)
	{
		al.add(st);
	}
	
	public void display()
	{
		System.out.println("CourseID: "+ CourseID);
		System.out.println("name: "+ name);
		System.out.println("instructor: "+ instructor);
		System.out.println("Entrolled Students:");
		for(Student s : al)
		{
			System.out.println(s.getName());
		}
		
	}
	
		
}
