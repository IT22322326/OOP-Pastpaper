package Q4;

public class HeatMissileSystem implements MissileSystem 
{
	private static HeatMissileSystem instance;
	
	private HeatMissileSystem()
	{
		
	}
	
	public static HeatMissileSystem getInstance()
	{
		if(instance==null)
		{
			instance=new HeatMissileSystem();
		}
		return instance;
	}
	
	@Override
	public void launch(String source) 
	{
		// TODO Auto-generated method stub
		System.out.println("Initialize Heat Missile System");
		System.out.println("HeatMissileSystem launch from "+ source);
	}

	@Override
	public void blast(String destination)
	{
		// TODO Auto-generated method stub
		System.out.println("Initialize Heat Missile System");
		System.out.println("HeatMissileSystem blast "+ destination);
	}

}
