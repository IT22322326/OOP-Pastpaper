package Q4;

public class Main {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		MissileSystem h1 = HeatMissileSystem.getInstance();
		MissileSystem r1 = RocketMissileSystem.getInstance();
		
		MissileOperation b1 = new BlastMissile();
		MissileOperation l1 = new LaunchMissile();
		
		MissileController m1 = MissileController.getInstance();
		
		m1.setBlast(h1);
		m1.setLaunch(r1);
		
		m1.performlaunching("India");
		m1.performblasting("srilanka");
		
		b1.initiateoperation("russia");
		l1.initiateoperation("colombo");
	}

}
