package Q4;

public class MissileController 
{
	private static MissileController instance;
	
	private MissileController()
	{
		
	}
	
	public static MissileController getInstance()
	{
		if(instance==null)
		{
			instance= new MissileController();
		}
		return instance;
	}
	
	
	private MissileSystem launch;
	private MissileSystem blast;
	
	
	public void setLaunch(MissileSystem launch) {
		this.launch = launch;
	}

	public void setBlast(MissileSystem blast) {
		this.blast = blast;
	}

	public void performlaunching(String start)
	{
		launch.launch(start);
	}
	
	public void performblasting(String end)
	{
		blast.blast(end);
	}
}
