package Q4;

public class BlastMissile implements MissileOperation 
{

	@Override
	public void initiateoperation(String location) 
	{
		// TODO Auto-generated method stub
		System.out.println("BlastMissile location is"+location);
	}

}
