package Q4;

public interface MissileOperation 
{
	 public void initiateoperation(String location);
}
