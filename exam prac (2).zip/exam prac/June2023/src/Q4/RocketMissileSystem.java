package Q4;

public class RocketMissileSystem implements MissileSystem 
{
	private static RocketMissileSystem instance;
	
	private RocketMissileSystem()
	{
		
	}
	
	public static RocketMissileSystem getInstance()
	{
		if(instance==null)
		{
			instance = new RocketMissileSystem();
		}
		return instance;
	}

	@Override
	public void launch(String source) 
	{
		// TODO Auto-generated method stub
		System.out.println("Initialize Rocket Missile System");
		System.out.println("RocketMissileSystem launch from "+ source);
	}

	@Override
	public void blast(String destination)
	{
		// TODO Auto-generated method stub
		System.out.println("Initialize Rocket Missile System");
		System.out.println("RocketMissileSystem blast"+ destination);
	}

}
