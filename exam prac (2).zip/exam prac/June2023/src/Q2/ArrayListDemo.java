package Q2;
import java.util.*;
public class ArrayListDemo
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		ArrayList<Integer> al = new ArrayList<>();
		ArrayList<Integer> al1 = new ArrayList<>();
		Scanner ms = new Scanner(System.in);
		int num;
		System.out.println("Enter the numbers:");
		while(true)
		{
			num = ms.nextInt();
			if(num==0)
			{
				break;
			}
			al.add(num);
		}
		
		for(Integer o:al)
		{
			if(o%2!=0)
			{
				al1.add(o);
		
			}
		}
		
		System.out.println("Odd Numbers: ");
		for(Integer odd : al1)
		{
			System.out.println(odd);
		}
	}

}
