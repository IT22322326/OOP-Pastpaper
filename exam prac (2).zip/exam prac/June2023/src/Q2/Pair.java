package Q2;

public class Pair<T, U> 
{
	T first;
	U second;
	
	public Pair(T first, U second) 
	{
		this.first = first;
		this.second = second;
	}

	public T getFirst()
	{
		return first;
	}

	public U getSecond()
	{
		return second;
	}
	
	public void display()
	{
		System.out.println("FirstValue:"+getFirst());
		System.out.println("SecondValue:"+getSecond());
	}
	
	
}
