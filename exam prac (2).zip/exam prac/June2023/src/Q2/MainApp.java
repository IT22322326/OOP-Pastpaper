package Q2;
import java.util.*;
public class MainApp 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Pair<String,Integer> p1 = new Pair("Test1",42);
		Pair<Double,String> p2 = new Pair(3.14,"Test2");
		
		System.out.println("Printing First pair");
		p1.display();
		
		System.out.println("Printing Second pair");
		p2.display();
		
		
	}

}
