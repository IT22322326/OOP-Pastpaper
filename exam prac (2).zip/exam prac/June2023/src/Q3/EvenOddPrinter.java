package Q3;

public class EvenOddPrinter 
{

	private static final int MAX_NUM = 20;
	private static volatile int nextNum = 0;
	private static final Object lock = new Object();
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Thread evenThread = new Thread(new EvenRunnable(lock) , "EvenThread") ;
		Thread oddThread = new Thread(new OddRunnable(lock) , "OddThread");
		
		evenThread.setName("evenThread");
		oddThread.setName("oddThread");
		
		evenThread.start();
		oddThread.start();

	}

}
