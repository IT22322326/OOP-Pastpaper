package Q3;

public class EvenRunnable implements Runnable
{
	Object lock;
	private static final int MAX_NUM=20;
	
	public EvenRunnable(Object lock) 
	{
		super();
		this.lock = lock;
	}

	@Override
	public void run() 
	{
		// TODO Auto-generated method stub
		synchronized (lock) 
		{
			for(int i =0;i<=MAX_NUM;i+=2)
			{
				System.out.println(Thread.currentThread().getName()+":"+i);
				lock.notify();
				try {
					lock.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
	}
	
	
	
}
