package Q3;

public class OddRunnable implements Runnable
{
	Object lock;
	private static final int MAX_NUM=20;
	
	
	public OddRunnable(Object lock)
	{
		super();
		this.lock = lock;
	}


	@Override
	public void run() 
	{
		synchronized (lock) 
		{
			for(int i = 1;i<=MAX_NUM;i+=2)
			{
				System.out.println(Thread.currentThread().getName()+": "+i);
				lock.notify();
				try {
					lock.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		// TODO Auto-generated method stub
		
	}

}
